from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def aboutme_view(request):
    # return HttpResponse('ABOUT ME') 
    return render(request , 'aboutme.html')