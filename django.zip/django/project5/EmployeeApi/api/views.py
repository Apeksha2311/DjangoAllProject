from django.shortcuts import render

from rest_framework import viewset

from .models import EmployeeModel

from .serializers import EmployeeSerializer

# Create your views here.

class api_view(viewset.modelviewset):
    query
    
